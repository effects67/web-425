var firstName: string= 'Gabriel';
var lastName: string= 'Vance';

function hello(firstName, lastName) {
    return 'Hello ' + firstName+ ' ' + lastName;
    }

console.log(hello(firstName, lastName));