var firstName = 'Gabriel';
var lastName = 'Vance';
function hello(firstName, lastName) {
    return 'Hello ' + firstName + ' ' + lastName;
}
console.log(hello(firstName, lastName));
